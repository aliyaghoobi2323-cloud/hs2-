module github.com/hosseintaghipoursori-alt/hs2-tunnel

go 1.27

require (
	github.com/flynn/noise v1.1.0
	github.com/refraction-networking/utls v1.6.7
	github.com/xtaci/smux v1.5.24
	golang.org/x/crypto v0.31.0
)

require (
	github.com/andybalholm/brotli v1.0.6 // indirect
	github.com/klauspost/compress v1.17.4 // indirect
	golang.org/x/sys v0.28.0 // indirect
)
